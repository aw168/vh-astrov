---
title: "朋友的新动态"
h1: "朋友的新动态 🎴"
desc: "来看看我的朋友们都在干嘛."
layout: "@/layouts/ToolLayout/ToolLayout.astro"
type: "friends"
---

:::note{type="error"}
如果你是我的邻居，但是没有在这里看到自己，可以立刻马上告诉我你的 RSS 订阅地址噢～
:::