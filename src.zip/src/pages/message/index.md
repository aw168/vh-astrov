---
title: "留言"
h1: "留言板 🌸"
desc: "快友之事莫若谈。"
layout: "@/layouts/ToolLayout/ToolLayout.astro"
type: "message"
---

:::note{type="info"}
期待你的畅所欲言～
:::
