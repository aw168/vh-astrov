---
title: "动态"
h1: "动态 🥫"
desc: "记录美好生活."
layout: "@/layouts/ToolLayout/ToolLayout.astro"
type: "talking"
---

:::note{type="import"}
这里记录着我想记录的生活～
:::
