---
title: 【开源】Web Watermark 图片添加水印在线小助手
categories: Daily
tags:
  - 开源
  - 水印
  - WebWatermark

id: Web-Watermark
cover: "https://i0.wp.com/uxiaohan.github.io/v2/2025/02/1739241633608.webp"
date: 2024-11-21 15:32:51
recommend: true
---

:::note
Web Watermark是一款在线的网页版可离线使用的安全的图片添加水印项目
:::

### 页面截图

![Web Watermark](https://i0.wp.com/uxiaohan.github.io/v2/2024/11/1732174890.webp)

::btn[点击体验]{link="https://watermark.vvhan.com/"}

### 项目地址

::btn[WebWatermark - Github]{link="https://github.com/uxiaohan/WebWatermark"}
